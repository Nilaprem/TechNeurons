﻿using Microsoft.AspNetCore.Mvc;
using techneurons.Data;
using techneurons.Models;

namespace techneurons.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly mvcdbcontext context;
        public EmployeeController(mvcdbcontext context)
        {
            this.context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(employee em)
        {
         
            var employee = new employee()
            {
                Id = Guid.NewGuid(),
                Name = em.Name,
                Email = em.Email,
                Task = em.Task


            };
           
            context.EmployeeTable.Add(employee);
            context.SaveChanges();
            return RedirectToAction("Index");
          

        }
        [HttpGet]
        public IActionResult Read()
        {
            var emp=context.EmployeeTable.ToList();
            return View(emp);
        }
        [HttpGet]
        public IActionResult Update(Guid id)
        {
            var update=context.EmployeeTable.FirstOrDefault(x=>x.Id==id);
            if (update != null)
            {
                var updatemodel = new updatemodel()
                {
                    Id = update.Id,
                    Name = update.Name,
                    Email = update.Email,
                    Task = update.Task
                };
                return View(updatemodel);
            }
            return RedirectToAction("Read");
           
        }
        [HttpPost]
        public IActionResult update(updatemodel model)
        {
            var emp=context.EmployeeTable.Find(model.Id);
            if (emp != null)
            {
                emp.Name = model.Name;
                emp.Email = model.Email;
                emp.Task = model.Task;

                
                context.SaveChanges();
                return RedirectToAction("Read");
            }
            return Redirect("Read");
        }

        [HttpPost]
        public IActionResult delete(updatemodel updatemodel) {
            var emp = context.EmployeeTable.Find(updatemodel.Id);
                {
                if (emp != null)
                {
                    context.EmployeeTable.Remove(emp);
                    context.SaveChanges();
                    return RedirectToAction("Read");
                }
                return RedirectToAction("Read");

            }
        }
    }
    
}
