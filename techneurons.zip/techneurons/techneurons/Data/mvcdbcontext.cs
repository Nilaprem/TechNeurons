﻿using Microsoft.EntityFrameworkCore;
using techneurons.Models;

namespace techneurons.Data
{
    public class mvcdbcontext:DbContext
    {
        public mvcdbcontext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<employee> EmployeeTable { get; set; }

    }
}

