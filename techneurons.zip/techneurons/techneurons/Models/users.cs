﻿namespace techneurons.Models
{
    public class users
    {
        public string Name {  get; set; }
        public string Email { get; set; }
        public string Task { get; set; }
    }
}
